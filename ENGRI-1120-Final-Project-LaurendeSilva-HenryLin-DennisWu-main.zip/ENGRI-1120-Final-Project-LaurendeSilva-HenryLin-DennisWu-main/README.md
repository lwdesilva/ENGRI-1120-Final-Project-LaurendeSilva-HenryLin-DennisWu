# ENGRI-1120-Final-Project-LaurendeSilva-HenryLin-DennisWu
ENGRI 1120: Design and Analysis of a Sustainable Cell-Free Production Process for Industrially Important Small Molecules by Lauren de Silva, Dennis Wu, and Henry Lin. 
